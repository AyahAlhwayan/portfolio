# Portfolio of Aya Alhwayan

## Contact
- 📧 Email: Aya_Alhwayan@outlook.com  
- 📞 Phone: +49 1575 3362979  
- 🌐 LinkedIn: [Scan the QR code in the folder]

## Documents
- **CV**: [Aya_Alhwayan_CV.pdf](Aya_Alhwayan_CV.pdf)
- **Business Card**: [Aya_Alhwayan_Business_Card.png](Aya_Alhwayan_Business_Card.png)
- **LinkedIn QR**: [LinkedIn QR Code](qr_aya_alhwayan_linkedin.png)
